<?php $depth = "/securify/" ?>
<div class="footer">
	<footer>
		<a href="<?php echo $depth; ?>about.php">&copy; 2024 Dinakar S</a>
	</footer>
</div>
